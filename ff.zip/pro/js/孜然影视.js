const _0x48c78e = _0x54f6;
(function (_0x3a7b4a, _0x58eae1) {
    const _0x4c8dc3 = _0x54f6, _0x35fbe3 = _0x3a7b4a();
    while (!![]) {
        try {
            const _0x542978 = -parseInt(_0x4c8dc3(0xbb)) / (0x11c1 + -0x7 * 0xc2 + -0xc72) * (parseInt(_0x4c8dc3(0x10a)) / (0x3 * -0x591 + -0xd * -0x1c9 + -0x680)) + -parseInt(_0x4c8dc3(0xd8)) / (-0x98a + 0x1142 + -0x1 * 0x7b5) * (parseInt(_0x4c8dc3(0x12e)) / (-0xae6 + 0x2 * -0x11b1 + 0x2e4c)) + -parseInt(_0x4c8dc3(0xc3)) / (0xf1 * -0x8 + -0x9 * 0x192 + 0x15af) + parseInt(_0x4c8dc3(0x12f)) / (-0x5 * 0x4fb + 0x25ee + -0xd01) + -parseInt(_0x4c8dc3(0xa0)) / (0x221d * 0x1 + 0x3cd * 0x7 + 0x3 * -0x143b) + -parseInt(_0x4c8dc3(0x129)) / (-0x44a + 0x21b * 0x7 + -0x7 * 0x17d) * (parseInt(_0x4c8dc3(0xe6)) / (-0x1f5b + -0x158e + 0x34f2)) + parseInt(_0x4c8dc3(0x123)) / (-0x3c + -0x2dd * -0x8 + 0x2 * -0xb51);
            if (_0x542978 === _0x58eae1)
                break;
            else
                _0x35fbe3['push'](_0x35fbe3['shift']());
        } catch (_0x7090da) {
            _0x35fbe3['push'](_0x35fbe3['shift']());
        }
    }
}(_0x1e9c, -0x14f995 + -0x1b375 * -0x5 + 0x16ffe4));
let host = _0x48c78e(0xea) + _0x48c78e(0xd3), headers = { 'User-Agent': _0x48c78e(0xf4) + _0x48c78e(0xcd) + _0x48c78e(0xb7) + _0x48c78e(0xe7) + _0x48c78e(0xdf) + _0x48c78e(0x103) + _0x48c78e(0xfa) + _0x48c78e(0xde) + _0x48c78e(0xb8) + _0x48c78e(0x12a) + _0x48c78e(0xb9) + _0x48c78e(0xc7) + _0x48c78e(0x11f) + _0x48c78e(0xe4) + _0x48c78e(0xa9) + _0x48c78e(0x126) };
async function init(_0x9bf808) {
}
function _0x54f6(_0x9b69d, _0x3b17d3) {
    const _0x1172b4 = _0x1e9c();
    return _0x54f6 = function (_0x4995e6, _0x53d438) {
        _0x4995e6 = _0x4995e6 - (-0x4c3 + 0x755 * 0x1 + -0x1f2);
        let _0x1f534e = _0x1172b4[_0x4995e6];
        return _0x1f534e;
    }, _0x54f6(_0x9b69d, _0x3b17d3);
}
function getList(_0x20072d) {
    const _0x5bc716 = _0x48c78e, _0x231d4b = {
            'PRLAd': function (_0x53aeed, _0x2d7483) {
                return _0x53aeed && _0x2d7483;
            },
            'EfdfG': function (_0xddf542, _0x5f5c4a) {
                return _0xddf542 + _0x5f5c4a;
            },
            'bcogk': _0x5bc716(0x10c),
            'BcNIl': function (_0x1f1ee8, _0x577a48, _0x5c0a59) {
                return _0x1f1ee8(_0x577a48, _0x5c0a59);
            },
            'XNJcA': _0x5bc716(0xb6) + 'em'
        };
    let _0x36de8c = [], _0x1e2c43 = _0x231d4b[_0x5bc716(0xf7)](pdfa, _0x20072d, _0x231d4b[_0x5bc716(0xa1)]);
    return _0x1e2c43[_0x5bc716(0x122)](_0x5a9290 => {
        const _0x5d2874 = _0x5bc716;
        let _0x33172d = _0x5a9290[_0x5d2874(0xf8)](/detail\/id\/(\d+).html/), _0x1d7f97 = _0x5a9290[_0x5d2874(0xf8)](/title="(.*?)"/) || _0x5a9290[_0x5d2874(0xf8)](/alt="(.*?)"/), _0x5d05c7 = _0x5a9290[_0x5d2874(0xf8)](/data-original="(.*?)"/) || _0x5a9290[_0x5d2874(0xf8)](/src="(.*?)"/), _0x5adda3 = _0x5a9290[_0x5d2874(0xf8)](/<div class="module-item-note">([^>]+)<\/div>/);
        if (_0x231d4b[_0x5d2874(0x10e)](_0x33172d, _0x1d7f97)) {
            let _0x526a23 = _0x5d05c7 ? _0x5d05c7[0x7ce + -0x34a * 0x6 + 0xd * 0xeb] || _0x5d05c7[0x25a6 + -0x2 * -0xefd + -0x439e] : '';
            _0x36de8c[_0x5d2874(0x102)]({
                'vod_id': _0x33172d[-0x293 * -0x7 + -0xa * -0x71 + -0x166e],
                'vod_name': _0x1d7f97[-0x9a2 * 0x1 + -0x178a + 0x212d][_0x5d2874(0x115)](/<.*?>/g, ''),
                'vod_pic': _0x526a23[_0x5d2874(0x108)]('/') ? _0x231d4b[_0x5d2874(0xe8)](host, _0x526a23) : _0x526a23,
                'vod_remarks': _0x231d4b[_0x5d2874(0xe8)](_0x231d4b[_0x5d2874(0xba)], (_0x5adda3 || [
                    '',
                    ''
                ])[0x3d * -0x7f + 0xdd7 + 0x5 * 0x349][_0x5d2874(0x115)](/<.*?>/g, '')[_0x5d2874(0x115)]('第', ''))
            });
        }
    }), _0x36de8c;
}
function _0x1e9c() {
    const _0x2ba8ae = [
        'matchAll',
        'Eavip',
        '$$$',
        '动作片',
        '7719sBzydQ',
        '\x20/\x20',
        '恐怖片',
        '科幻片',
        '爱情片',
        'KoVAq',
        'ppleWebKit',
        'C\x20Build/TK',
        '国产动漫',
        '/index.php',
        'stringify',
        'join',
        '.0.7499.3\x20',
        '.tab-item',
        '4872888cWHwsw',
        ';\x20M2102J2S',
        'EfdfG',
        'yyqxK',
        'https://zr',
        'UzaQh',
        'POYFL',
        'lGWsX',
        'dmEAZ',
        'pyqKE',
        'iIdUe',
        '其他动漫',
        '/vod/detai',
        'edzDi',
        'Mozilla/5.',
        '港台剧',
        'AHRow',
        'BcNIl',
        'match',
        'zgdKh',
        '001;\x20wv)\x20A',
        'NvAeg',
        'clXmh',
        'PWaRA',
        'AiNbj',
        '✨vox👉',
        '/vod/searc',
        'tlijA',
        'push',
        'Q1.221114.',
        'content',
        '/wd/',
        'xbwdm',
        'kRJsD',
        'startsWith',
        '/page/',
        '138666GrcGqV',
        '内地综艺',
        '✨vox甄选✨',
        'KuhCD',
        'PRLAd',
        'SuGzi',
        'ABpxf',
        'CKXBF',
        '韩国综艺',
        'KIOQe',
        'DMeRB',
        'replace',
        'id/',
        'mQnbI',
        'TXDYR',
        '喜剧片',
        'jBGQl',
        '港台综艺',
        '📢本资源来源于网络🚓',
        'ErWaP',
        '😸vox🎉为你介绍剧情',
        'Chrome/143',
        'pagBu',
        'iwCST',
        'forEach',
        '29985680FrUILE',
        'trim',
        'UhlTd',
        'ari/537.36',
        'IOnVg',
        'cIuHu',
        '16ooXevz',
        'HTML,\x20like',
        'xFhpY',
        'from',
        'KqMDc',
        '220CeycdS',
        '178308nZJuEY',
        'KiZll',
        'aiRLU',
        '4880757MEJgTZ',
        'XNJcA',
        'class',
        '欧美剧',
        'vEAkA',
        'PjkkM',
        'opeFo',
        '侵权请联系删除👉',
        'qlsGE',
        'Mobile\x20Saf',
        'l/id/',
        'Vvcfs',
        'lmJlY',
        'ay-list-co',
        'gmpRQ',
        'nfauU',
        'adkok',
        'map',
        '.module-pl',
        'fmzOw',
        '/vod/show/',
        '国产剧',
        '.module-it',
        'Android\x2013',
        '/537.36\x20(K',
        '\x20Gecko)\x20Ve',
        'bcogk',
        '3jlTaZq',
        'page/',
        '日本动漫',
        'gvocr',
        'pgqAT',
        '欧美动漫',
        '📽️vox👉',
        'pEczO',
        '1042925fqetBd',
        'DUSMe',
        '.html',
        'Rwdpk',
        'rsion/4.0\x20',
        'paOZN',
        'ntent',
        'InayJ',
        '/vod/play/',
        'QhGkF',
        '0\x20(Linux;\x20',
        'JyqVZ',
        'akbXM',
        '日本综艺',
        'mpglL',
        '短视频',
        'ys.pw'
    ];
    _0x1e9c = function () {
        return _0x2ba8ae;
    };
    return _0x1e9c();
}
async function home(_0x2cc051) {
    const _0x989328 = _0x48c78e, _0x8626f5 = {
            'TXDYR': _0x989328(0xd2),
            'PWaRA': _0x989328(0xa2),
            'xbwdm': _0x989328(0xd7),
            'InayJ': _0x989328(0x119),
            'dmEAZ': _0x989328(0xdc),
            'iwCST': _0x989328(0xdb),
            'gvocr': _0x989328(0xda),
            'ABpxf': _0x989328(0xb5),
            'AHRow': _0x989328(0xf5),
            'QhGkF': _0x989328(0xa3),
            'lGWsX': _0x989328(0x10b),
            'Eavip': _0x989328(0x11b),
            'KqMDc': _0x989328(0xd0),
            'JyqVZ': _0x989328(0x112),
            'zgdKh': _0x989328(0xe0),
            'pagBu': _0x989328(0xbd),
            'kRJsD': _0x989328(0xc0),
            'POYFL': _0x989328(0xf1)
        };
    return JSON[_0x989328(0xe2)]({
        'class': [
            {
                'type_id': '1',
                'type_name': '电影'
            },
            {
                'type_id': '2',
                'type_name': '剧集'
            },
            {
                'type_id': '3',
                'type_name': '综艺'
            },
            {
                'type_id': '4',
                'type_name': '动漫'
            },
            {
                'type_id': '47',
                'type_name': _0x8626f5[_0x989328(0x118)]
            }
        ],
        'filters': {
            '1': [{
                    'key': _0x8626f5[_0x989328(0xfd)],
                    'name': '类型',
                    'value': [
                        {
                            'n': '全部',
                            'v': ''
                        },
                        {
                            'n': _0x8626f5[_0x989328(0x106)],
                            'v': '6'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xca)],
                            'v': '7'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xee)],
                            'v': '8'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0x121)],
                            'v': '9'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xbe)],
                            'v': '11'
                        }
                    ]
                }],
            '2': [{
                    'key': _0x8626f5[_0x989328(0xfd)],
                    'name': '类型',
                    'value': [
                        {
                            'n': '全部',
                            'v': ''
                        },
                        {
                            'n': _0x8626f5[_0x989328(0x110)],
                            'v': '13'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xf6)],
                            'v': '14'
                        },
                        {
                            'n': '日剧',
                            'v': '15'
                        },
                        {
                            'n': '韩剧',
                            'v': '33'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xcc)],
                            'v': '16'
                        }
                    ]
                }],
            '3': [{
                    'key': _0x8626f5[_0x989328(0xfd)],
                    'name': '类型',
                    'value': [
                        {
                            'n': '全部',
                            'v': ''
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xed)],
                            'v': '27'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xd5)],
                            'v': '28'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0x12d)],
                            'v': '29'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xce)],
                            'v': '36'
                        }
                    ]
                }],
            '4': [{
                    'key': _0x8626f5[_0x989328(0xfd)],
                    'name': '类型',
                    'value': [
                        {
                            'n': '全部',
                            'v': ''
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xf9)],
                            'v': '31'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0x120)],
                            'v': '32'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0x107)],
                            'v': '42'
                        },
                        {
                            'n': _0x8626f5[_0x989328(0xec)],
                            'v': '43'
                        }
                    ]
                }]
        }
    });
}
async function homeVod() {
    const _0x4a7d51 = _0x48c78e, _0x16e04b = {
            'PjkkM': function (_0x458554, _0x4dbc52, _0x4509fa) {
                return _0x458554(_0x4dbc52, _0x4509fa);
            },
            'DUSMe': function (_0x9c5733, _0x22f6c0) {
                return _0x9c5733(_0x22f6c0);
            }
        };
    let _0x4cf879 = await _0x16e04b[_0x4a7d51(0xa5)](req, host, { 'headers': headers });
    return JSON[_0x4a7d51(0xe2)]({ 'list': _0x16e04b[_0x4a7d51(0xc4)](getList, _0x4cf879[_0x4a7d51(0x104)]) });
}
async function category(_0x56e4f6, _0x670029, _0x4fc972, _0x81942d) {
    const _0x37377c = _0x48c78e, _0x312362 = {
            'adkok': function (_0x542821, _0x393c4c) {
                return _0x542821 || _0x393c4c;
            },
            'KIOQe': function (_0x5dc9b3, _0x34f50a) {
                return _0x5dc9b3 + _0x34f50a;
            },
            'IOnVg': function (_0x479709, _0x3e244d) {
                return _0x479709 + _0x3e244d;
            },
            'ErWaP': function (_0x4a6d5c, _0x412f54) {
                return _0x4a6d5c + _0x412f54;
            },
            'tlijA': _0x37377c(0xe1) + _0x37377c(0xb4) + _0x37377c(0x116),
            'mpglL': function (_0x5224fd, _0x20ede8) {
                return _0x5224fd > _0x20ede8;
            },
            'fmzOw': function (_0x5518ed, _0x59cd32) {
                return _0x5518ed(_0x59cd32);
            },
            'yyqxK': function (_0x566b76, _0x55cae7) {
                return _0x566b76 + _0x55cae7;
            },
            'Rwdpk': _0x37377c(0xbc),
            'vEAkA': _0x37377c(0xc5),
            'DMeRB': function (_0x19b00e, _0x369a80, _0x5aa167) {
                return _0x19b00e(_0x369a80, _0x5aa167);
            }
        };
    let _0x1578b6 = _0x312362[_0x37377c(0xb0)](_0x670029, 0x7a9 + -0x16e8 * -0x1 + -0x1e90), _0x5bcc0b = _0x81942d && _0x81942d[_0x37377c(0xa2)] ? _0x81942d[_0x37377c(0xa2)] : _0x56e4f6, _0x57a28d = _0x312362[_0x37377c(0x113)](_0x312362[_0x37377c(0x127)](_0x312362[_0x37377c(0x127)](_0x312362[_0x37377c(0x11d)](host, _0x312362[_0x37377c(0x101)]), _0x5bcc0b), '/'), _0x312362[_0x37377c(0xd1)](_0x312362[_0x37377c(0xb3)](parseInt, _0x1578b6), -0xeb7 + -0x2 * 0x62a + -0x482 * -0x6) ? _0x312362[_0x37377c(0xe9)](_0x312362[_0x37377c(0x113)](_0x312362[_0x37377c(0xc6)], _0x1578b6), _0x312362[_0x37377c(0xa4)]) : ''), _0x3bc68f = await _0x312362[_0x37377c(0x114)](req, _0x57a28d, { 'headers': headers });
    return JSON[_0x37377c(0xe2)]({
        'list': _0x312362[_0x37377c(0xb3)](getList, _0x3bc68f[_0x37377c(0x104)]),
        'page': _0x312362[_0x37377c(0xb3)](parseInt, _0x1578b6)
    });
}
async function detail(_0x43cc25) {
    const _0x162935 = _0x48c78e, _0x36e114 = {
            'UhlTd': function (_0x323f83, _0x568b58) {
                return _0x323f83 + _0x568b58;
            },
            'aiRLU': _0x162935(0xc1),
            'UzaQh': function (_0x36c960, _0x32627b) {
                return _0x36c960 + _0x32627b;
            },
            'lmJlY': _0x162935(0xd9),
            'KuhCD': function (_0x1d25b7, _0x570644) {
                return _0x1d25b7 + _0x570644;
            },
            'akbXM': function (_0x489808, _0x725c5e) {
                return _0x489808 + _0x725c5e;
            },
            'nfauU': _0x162935(0xe1) + _0x162935(0xf2) + _0x162935(0xaa),
            'KiZll': _0x162935(0xc5),
            'SuGzi': function (_0x224677, _0x1cff52, _0xc64055) {
                return _0x224677(_0x1cff52, _0xc64055);
            },
            'KoVAq': function (_0x46956d, _0xd6f212, _0x2eea6c) {
                return _0x46956d(_0xd6f212, _0x2eea6c);
            },
            'CKXBF': _0x162935(0xe5),
            'paOZN': _0x162935(0xd6),
            'AiNbj': function (_0x2d2ebc, _0x21355b, _0x5791b2) {
                return _0x2d2ebc(_0x21355b, _0x5791b2);
            },
            'mQnbI': _0x162935(0xb2) + _0x162935(0xad) + _0x162935(0xc9),
            'xFhpY': function (_0x1e697a, _0x2f49db) {
                return _0x1e697a + _0x2f49db;
            },
            'Vvcfs': _0x162935(0x11e) + _0x162935(0x11c) + _0x162935(0xa7)
        };
    let _0x709862 = _0x36e114[_0x162935(0xeb)](_0x36e114[_0x162935(0x10d)](_0x36e114[_0x162935(0xcf)](host, _0x36e114[_0x162935(0xaf)]), _0x43cc25), _0x36e114[_0x162935(0x130)]), _0x5538fc = await _0x36e114[_0x162935(0x10f)](req, _0x709862, { 'headers': headers }), _0x48804f = _0x5538fc[_0x162935(0x104)], _0x2d063d = _0x36e114[_0x162935(0xdd)](pdfa, _0x48804f, _0x36e114[_0x162935(0x111)])[_0x162935(0xb1)](_0x542923 => _0x162935(0xff) + (_0x542923[_0x162935(0xf8)](/<span>(.*?)<\/span>/) || [
            '',
            '线路'
        ])[0x115 * -0x4 + 0x1f97 + 0x6 * -0x48b])[_0x162935(0xe3)](_0x36e114[_0x162935(0xc8)]), _0x255937 = _0x36e114[_0x162935(0xfe)](pdfa, _0x48804f, _0x36e114[_0x162935(0x117)])[_0x162935(0xb1)](_0x431c0c => pdfa(_0x431c0c, 'a')[_0x162935(0xb1)](_0x5b70f5 => {
            const _0x5100f3 = _0x162935;
            let _0x3f1617 = _0x36e114[_0x5100f3(0x125)](_0x36e114[_0x5100f3(0x131)], (_0x5b70f5[_0x5100f3(0xf8)](/<span>(.*?)<\/span>/) || [
                    '',
                    '播放'
                ])[-0x816 + -0x13 * -0x1bf + -0x1916]), _0x38ddc7 = _0x5b70f5[_0x5100f3(0xf8)](/href="\/index.php\/vod\/play\/id\/(.*?).html"/);
            return _0x36e114[_0x5100f3(0xeb)](_0x36e114[_0x5100f3(0x125)](_0x3f1617, '$'), _0x38ddc7 ? _0x38ddc7[-0x2fb + 0x200b + 0x2b * -0xad] : '');
        })[_0x162935(0xe3)]('#'))[_0x162935(0xe3)](_0x36e114[_0x162935(0xc8)]);
    return JSON[_0x162935(0xe2)]({
        'list': [{
                'vod_id': _0x43cc25,
                'vod_name': (_0x48804f[_0x162935(0xf8)](/<h1>(.*?)<\/h1>/) || [
                    '',
                    ''
                ])[-0x1546 + 0x22 * -0x2b + 0x1afd],
                'vod_pic': (_0x48804f[_0x162935(0xf8)](/data-original="(.*?)"/) || [
                    '',
                    ''
                ])[-0x2545 + -0x1 * -0x1f1f + 0x627],
                'vod_year': (_0x48804f[_0x162935(0xf8)](/<a title="(\d{4})" href="\/index.php\/vod\/show\/id\/(\d+)\/year\/(\d{4}).html">(\d{4})<\/a>/) || [
                    '',
                    ''
                ])[-0x187e + 0x64 * 0x18 + 0x7 * 0x229],
                'vod_area': (_0x48804f[_0x162935(0xf8)](/<a title="([^>]+)" href="\/index.php\/vod\/show\/area\/([^>]+)\/id\/(\d+).html">([^>]+)<\/a>/) || [
                    '',
                    ''
                ])[0x257b + 0x58c + -0x2b06],
                'vod_lang': (_0x48804f[_0x162935(0xf8)](/<span class="module-info-item-title">语言：<\/span>\s*<div class="module-info-item-content">\s*([^<]+)\s*<\/div>/) || [
                    '',
                    ''
                ])[-0x2af * -0x2 + 0x1 * 0x1fe7 + -0x35 * 0xb4][_0x162935(0x124)](),
                'vod_remarks': (_0x48804f[_0x162935(0xf8)](/<span class="module-info-item-title">集数：<\/span>\s*<div class="module-info-item-content">\s*([^<]+)\s*<\/div>/) || _0x48804f[_0x162935(0xf8)](/<span class="module-info-item-title">备注：<\/span>\s*<div class="module-info-item-content">\s*([^<]+)\s*<\/div>/) || _0x48804f[_0x162935(0xf8)](/<span class="module-info-item-title">连载：<\/span>\s*<div class="module-info-item-content">\s*([^<]+)\s*<\/div>/) || [
                    '',
                    ''
                ])[-0x883 * -0x3 + 0xff8 + -0x2980][_0x162935(0x124)](),
                'type_name': ((() => {
                    const _0x3ce61b = _0x162935, _0x58046f = Array[_0x3ce61b(0x12c)](_0x48804f[_0x3ce61b(0xd4)](/<div class="module-info-tag-link">([\s\S]*?)<\/div>/g)), _0xf1e7c5 = _0x58046f[0xa75 + -0x23be + 0x194b];
                    if (!_0xf1e7c5)
                        return '';
                    return Array[_0x3ce61b(0x12c)](_0xf1e7c5[-0x2 * -0x1381 + -0xe64 + -0x189d][_0x3ce61b(0xd4)](/<a[^>]*>([^<]+)<\/a>/g), _0x3978e8 => _0x3978e8[0x2439 + -0x1 * -0x20ef + -0x4527][_0x3ce61b(0x124)]())[_0x3ce61b(0xe3)](_0x36e114[_0x3ce61b(0xac)]);
                })()),
                'vod_actor': Array[_0x162935(0x12c)](_0x48804f[_0x162935(0xf8)](/<span class="module-info-item-title">主演：<\/span>\s*<div class="module-info-item-content">([\s\S]*?)<\/div>/)?.[-0x2 * 0x1f3 + -0x1 * -0xc5 + 0x322 * 0x1]?.[_0x162935(0xd4)](/<a [^>]*>([^<]+)<\/a>/g) || [])[_0x162935(0xb1)](_0x261bee => _0x261bee[0x185f + -0x5e9 * -0x3 + 0x1 * -0x2a19])[_0x162935(0xe3)](_0x36e114[_0x162935(0xac)]) || '',
                'vod_director': Array[_0x162935(0x12c)](_0x48804f[_0x162935(0xf8)](/<span class="module-info-item-title">导演：<\/span>\s*<div class="module-info-item-content">([\s\S]*?)<\/div>/)?.[-0x419 * 0x2 + 0x583 * 0x5 + -0x135c]?.[_0x162935(0xd4)](/<a [^>]*>([^<]+)<\/a>/g) || [])[_0x162935(0xb1)](_0x5adbea => _0x5adbea[-0x2 * 0xc5e + -0xdfb * -0x2 + 0xf * -0x37])[_0x162935(0xe3)](_0x36e114[_0x162935(0xac)]) || '',
                'vod_content': _0x36e114[_0x162935(0x12b)](_0x36e114[_0x162935(0xab)], (_0x48804f[_0x162935(0xf8)](/module-info-introduction">.*?<p>(.*?)<\/p>/s) || [
                    '',
                    ''
                ])[0xe5e + 0x1bcf + 0x1516 * -0x2][_0x162935(0x115)](/<.*?>/g, '')),
                'vod_play_from': _0x2d063d,
                'vod_play_url': _0x255937
            }]
    });
}
async function search(_0xcc2fac, _0x11f660, _0x10c825) {
    const _0x3c2dcb = _0x48c78e, _0x37620f = {
            'jBGQl': function (_0x4ef2bd, _0x2c3bef) {
                return _0x4ef2bd || _0x2c3bef;
            },
            'opeFo': function (_0x526496, _0x150358) {
                return _0x526496 + _0x150358;
            },
            'NvAeg': function (_0x39f1d5, _0x2a82e8) {
                return _0x39f1d5 > _0x2a82e8;
            },
            'edzDi': function (_0x477da0, _0x3f3ec0) {
                return _0x477da0(_0x3f3ec0);
            },
            'clXmh': function (_0x2c117a, _0x1a8911) {
                return _0x2c117a(_0x1a8911);
            },
            'iIdUe': function (_0x4e71dc, _0x18c868, _0x264bb4) {
                return _0x4e71dc(_0x18c868, _0x264bb4);
            },
            'pEczO': function (_0x1fc3e6, _0x572b77) {
                return _0x1fc3e6(_0x572b77);
            }
        };
    let _0x464799 = _0x37620f[_0x3c2dcb(0x11a)](_0x10c825, 0x7f * -0x2b + -0x1 * 0x218 + 0x176e), _0x3fb1f4 = _0x37620f[_0x3c2dcb(0xa6)](_0x37620f[_0x3c2dcb(0xa6)](host + (_0x3c2dcb(0xe1) + _0x3c2dcb(0x100) + 'h'), _0x37620f[_0x3c2dcb(0xfb)](_0x37620f[_0x3c2dcb(0xf3)](parseInt, _0x464799), -0x1 * -0x2d1 + 0xf57 + -0x1227) ? _0x3c2dcb(0x109) + _0x464799 : ''), _0x3c2dcb(0x105) + _0x37620f[_0x3c2dcb(0xfc)](encodeURIComponent, _0xcc2fac) + _0x3c2dcb(0xc5)), _0x2b47f1 = await _0x37620f[_0x3c2dcb(0xf0)](req, _0x3fb1f4, { 'headers': headers });
    return JSON[_0x3c2dcb(0xe2)]({ 'list': _0x37620f[_0x3c2dcb(0xc2)](getList, _0x2b47f1[_0x3c2dcb(0x104)]) });
}
async function play(_0x20da54, _0x2cb770, _0x4fd940) {
    const _0x3c0580 = _0x48c78e, _0x3d83af = {
            'gmpRQ': function (_0x4446bb, _0x3a33d1) {
                return _0x4446bb + _0x3a33d1;
            },
            'pgqAT': function (_0x4a8928, _0x101ed7) {
                return _0x4a8928 + _0x101ed7;
            },
            'qlsGE': _0x3c0580(0xe1) + _0x3c0580(0xcb) + _0x3c0580(0x116),
            'pyqKE': _0x3c0580(0xc5),
            'cIuHu': function (_0x5d3f0f, _0x4fcb0d, _0x52ba8c) {
                return _0x5d3f0f(_0x4fcb0d, _0x52ba8c);
            }
        };
    let _0x1a8ab4 = _0x3d83af[_0x3c0580(0xae)](_0x3d83af[_0x3c0580(0xae)](_0x3d83af[_0x3c0580(0xbf)](host, _0x3d83af[_0x3c0580(0xa8)]), _0x2cb770), _0x3d83af[_0x3c0580(0xef)]), _0x184045 = await _0x3d83af[_0x3c0580(0x128)](req, _0x1a8ab4, { 'headers': headers }), _0x3c38b8 = _0x184045[_0x3c0580(0x104)][_0x3c0580(0xf8)](/"url":"([^"]+\.m3u8)"/);
    if (_0x3c38b8)
        return JSON[_0x3c0580(0xe2)]({
            'parse': 0x0,
            'url': _0x3c38b8[-0x1c22 + 0x301 * -0x2 + 0x2225 * 0x1][_0x3c0580(0x115)](/\\/g, ''),
            'header': headers
        });
    return JSON[_0x3c0580(0xe2)]({
        'parse': 0x1,
        'url': _0x1a8ab4,
        'header': headers
    });
}
export default {
    'init': init,
    'home': home,
    'homeVod': homeVod,
    'category': category,
    'detail': detail,
    'search': search,
    'play': play
};